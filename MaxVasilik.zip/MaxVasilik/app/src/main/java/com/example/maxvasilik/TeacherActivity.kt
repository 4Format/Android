package com.example.maxvasilik

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.maxvasilik.databinding.ActivityTeacherBinding

class TeacherActivity : AppCompatActivity() {
    lateinit var binding: ActivityTeacherBinding
    private val adapter = TeacherAdapter()
    private val nameT = listOf("Вікторія Красничук", "Ляшеник Андрій", "Дуб Тетяна")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    private fun init() {
        binding.apply {
            rcViewTea.layoutManager = LinearLayoutManager(this@TeacherActivity)
            rcViewTea.adapter = adapter

            for (name in nameT){
                val teacher = Teacher(name)
                adapter.addTeacher(teacher)
            }


        }
    }
}