package com.example.maxvasilik

data class Group(val Name: String)