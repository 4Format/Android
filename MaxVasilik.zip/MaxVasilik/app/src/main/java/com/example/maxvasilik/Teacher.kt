package com.example.maxvasilik

data class Teacher(val Name: String)