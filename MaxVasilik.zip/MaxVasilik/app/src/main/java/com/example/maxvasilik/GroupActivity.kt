package com.example.maxvasilik

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.maxvasilik.databinding.ActivityGroupBinding

class GroupActivity : AppCompatActivity() {
    lateinit var binding: ActivityGroupBinding
    private val adapter = GroupAdapter()
    private val nameT = listOf("П-11", "П-41", "П-32")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGroupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    private fun init() {
        binding.apply {
            rcViewGrp.layoutManager = LinearLayoutManager(this@GroupActivity)
            rcViewGrp.adapter = adapter

            for (name in nameT){
                val group = Group(name)
                adapter.addGroup(group)
            }


        }
    }
}