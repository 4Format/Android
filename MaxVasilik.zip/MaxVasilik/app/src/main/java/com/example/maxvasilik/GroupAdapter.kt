package com.example.maxvasilik

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.maxvasilik.databinding.GroupItemBinding

class GroupAdapter: RecyclerView.Adapter<GroupAdapter.GroupHolder>() {
    var groupList = ArrayList<Group>()
    class GroupHolder(item: View): RecyclerView.ViewHolder(item) {
        val binding = GroupItemBinding.bind(item)
        fun bind(group: Group) = with(binding){
            groupName.text = group.Name

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GroupHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.group_item, parent, false)
        return GroupHolder(view)
    }

    override fun getItemCount(): Int {
        return groupList.size
    }

    override fun onBindViewHolder(holder: GroupHolder, position: Int) {
        holder.bind(groupList[position])
    }
    fun addGroup(group: Group){
        groupList.add(group)
    }
}